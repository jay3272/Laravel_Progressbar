<script>
</script><?php /**PATH C:\Users\cty22\Desktop\Coureses\Laravel\projects\03. routes_and_frontend\pb_frontend_assets\resources\views/layouts/js.blade.php ENDPATH**/ ?>