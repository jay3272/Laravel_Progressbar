<?php

echo "Home page"; ?><?php /**PATH C:\Users\cty22\Desktop\pb_frontend_assets\resources\views/home.blade.php ENDPATH**/ ?>