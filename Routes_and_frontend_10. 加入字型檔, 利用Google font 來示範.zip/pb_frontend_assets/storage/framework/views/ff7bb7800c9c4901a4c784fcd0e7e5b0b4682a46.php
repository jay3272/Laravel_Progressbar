

<?php $__env->startSection('content'); ?>
<main id="pb">
        <h1 class="title">Home</h1>
        <div class="card">
            <p class="title">Title</p>
            <div class="description">
                <p>description description</p>
                <p>description description</p>
                <p>description description</p>
            </div>
        </div>
        <br/>
        <p>outside!!!!</p>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inline_js'); ?>
    ##parent-placeholder-b2aa5d78b122f07e4877e2f51d925a686109b985##
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cty22\Desktop\Coureses\Laravel\projects\03. routes_and_frontend\pb_frontend_assets\resources\views/pb.blade.php ENDPATH**/ ?>