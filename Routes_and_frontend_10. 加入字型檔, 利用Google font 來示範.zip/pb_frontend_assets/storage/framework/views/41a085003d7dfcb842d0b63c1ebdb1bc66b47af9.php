<script>
</script><?php /**PATH C:\Users\cty22\Desktop\Coureses\Laravel\projects\pb_frontend_assets\resources\views/layouts/js.blade.php ENDPATH**/ ?>