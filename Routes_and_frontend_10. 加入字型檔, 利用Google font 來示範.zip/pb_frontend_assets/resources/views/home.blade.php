@extends('layouts.app')

@section('content')

<h1>Home page</h1>

@endsection

@section('inline_js')
    @parent
@endsection